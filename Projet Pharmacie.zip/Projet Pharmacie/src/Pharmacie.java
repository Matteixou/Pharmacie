// Classe Pharmacie
class Pharmacie {
    private Medicament[] medics;
    private int count;

    public Pharmacie(int taille) {
        medics = new Medicament[taille];
        count = 0;
    }

    public int recherche(int ref) {
        for (int i = 0; i < count; i++) {
            if (medics[i].getReference() == ref) {
                return i;
            }
        }
        return -1;
    }

    public void ajouter(Medicament M) {
        if (recherche(M.getReference()) == -1 && count < medics.length) {
            medics[count++] = M;
        }
    }

    public int supprimer(int ref) {
        int index = recherche(ref);
        if (index != -1) {
            medics[index] = medics[count - 1];
            medics[count - 1] = null;
            count--;
            return 1;
        }
        return 0;
    }

    public void afficheCategorie(int c) {
        for (int i = 0; i < count; i++) {
            if ((c == 1 && medics[i] instanceof Antibiotique) || (c == 2 && medics[i] instanceof AntiInflammatoire)) {
                System.out.println(medics[i]);
            }
        }
    }

    public String toString() {
        String res = "Pharmacie :\n";
        for (int i = 0; i < count; i++) {
            res += medics[i] + "\n";
        }
        return res;
    }
}