// Classe TestPharmacie
public class TestPharmacie {
    public static void main(String[] args) {
        Pharmacie pharma = new Pharmacie(10);

        Antibiotique a1 = new Antibiotique("2024-01-01", "Amoxicilline", 10.0, 101, "E. Coli");
        Antibiotique a2 = new Antibiotique("2024-02-01", "Azithromycine", 12.0, 102, "Streptocoque");
        AntiInflammatoire ai1 = new AntiInflammatoire("2024-03-01", "IbuprofÃ¨ne", 8.0, 220, "IbuprofÃ¨ne");
        AntiInflammatoire ai2 = new AntiInflammatoire("2024-04-01", "DiclofÃ©nac", 9.5, 221, "DiclofÃ©nac");

        pharma.ajouter(a1);
        pharma.ajouter(a2);
        pharma.ajouter(ai1);
        pharma.ajouter(ai2);

        System.out.println(pharma);
        System.out.println("Antibiotiques :");
        pharma.afficheCategorie(1);

        System.out.println("Anti-inflammatoires :");
        pharma.afficheCategorie(2);

        pharma.supprimer(220);
        System.out.println("AprÃ¨s suppression d'un anti-inflammatoire :");
        pharma.afficheCategorie(2);
    }
}