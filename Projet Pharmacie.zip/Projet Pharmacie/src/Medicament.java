// Classe Medicament
class Medicament {
    private String dateFabrication;
    private String libelle;
    private double prixHT;
    private int reference;

    public Medicament(String dateFabrication, String libelle, double prixHT, int reference) {
        this.dateFabrication = dateFabrication;
        this.libelle = libelle;
        this.prixHT = prixHT;
        this.reference = reference;
    }

    public int getReference() {
        return reference;
    }

    public String toString() {
        return "RÃ©fÃ©rence: " + reference + ", LibellÃ©: " + libelle + ", Prix HT: " + prixHT + "â‚¬, Fabrication: " + dateFabrication;
    }
}
