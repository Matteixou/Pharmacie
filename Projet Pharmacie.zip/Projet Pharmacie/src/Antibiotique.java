// Classe Antibiotique
class Antibiotique extends Medicament {
    private String bacterie;

    public Antibiotique(String dateFabrication, String libelle, double prixHT, int reference, String bacterie) {
        super(dateFabrication, libelle, prixHT, reference);
        this.bacterie = bacterie;
    }

    public double prixPublic() {
        return super.prixHT * 1.05;
    }

    public String toString() {
        return super.toString() + ", BactÃ©rie: " + bacterie + ", Prix Public: " + prixPublic() + "â‚¬";
    }
}



