// Classe AntiInflammatoire
class AntiInflammatoire extends Medicament {
    private String molecule;

    public AntiInflammatoire(String dateFabrication, String libelle, double prixHT, int reference, String molecule) {
        super(dateFabrication, libelle, prixHT, reference);
        this.molecule = molecule;
    }

    public double prixPublic() {
        return super.prixHT * 1.02;
    }

    public String toString() {
        return super.toString() + ", MolÃ©cule: " + molecule + ", Prix Public: " + prixPublic() + "â‚¬";
    }
}